/*
 * exp6.c
 *
 * Created: 4/20/2017 10:34:05 AM
 *  Author: USER
 */ 


#define D4 eS_PORTD4
#define D5 eS_PORTD5
#define D6 eS_PORTD6
#define D7 eS_PORTD7
#define RS eS_PORTC6
#define EN eS_PORTC7
#define ctrl PORTB
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#define F_CPU 8000000UL
#define BAUD 9600
#define BAUDRATE ((F_CPU)/(BAUD*16UL)-1)
#include <util/delay.h>
void usartinit();
void send();
unsigned char rxvalue(void);
void uart_transmit(unsigned char);
unsigned char rxdata,a,cmd,b;
unsigned int z;
unsigned char message[15];
unsigned char cmd1[]={"AT"};
unsigned char cmd2[]={"AT+CMGF=1"};
unsigned char cmd3[]={"AT+CMGS="};
unsigned char cmd4[]={"Run"};
unsigned char cmd5[]={"+8801836456993"};

int main(void)
{
	unsigned int result;
	float volt;
	
    DDRB = 0xFF;
    DDRC = 0xFF;
   
	
	ADMUX = 0b01100000;
	ADCSRA = 0b10000010;
	_delay_ms(50);
	usartinit();

	while(1) {
		ADCSRA |= (1<<ADSC);
		
		while( ADCSRA & (1<<ADSC) )
			;
			
		result = ADCL;
		result = (result>>6) | (ADCH<<2);
		
		
		volt = result*4.88/1000;
		if(volt>1.5){
			PORTB=0b00000001;
			send();
		}else{
			PORTB=0b00000000;
		}
		
		_delay_ms(100);
	}
	
    
}
void usartinit()
{
	UBRRH=00;
	UBRRL=77;
	UCSRB|=(1<<RXEN)|(1<<TXEN);
	UCSRC|=(1<<URSEL)|(1<<UCSZ0)|(1<<UCSZ1);
}
unsigned char rxvalue(void)
{
	while(!(UCSRA&(1<<RXC)));
	{
		rxdata=UDR;
		return rxdata;
	}
}
void send(){
	
	for(z=0;z<2;z++)
	{
		UDR = cmd1[z];
		_delay_ms(100);
	}
	UDR = ('\r');
	_delay_ms(500);
	for(z=0;z<9;z++)
	{
		UDR = cmd2[z];
		_delay_ms(100);
	}
	UDR = ('\r');
	_delay_ms(500);
	for(z=0;z<8;z++)
	{
		UDR = cmd3[z];
		_delay_ms(100);
	}
	UDR = ('"');
	_delay_ms(100);
	for(z=0;z<14;z++)
	{
		UDR = cmd5[z];
		_delay_ms(100);
	}
	UDR = ('"');
	_delay_ms(100);
	UDR = ('\r');
	_delay_ms(500);
	for(z=0;z<3;z++)
	{
		UDR = cmd4[z];
		_delay_ms(100);
	}
	UDR = (26);
	_delay_ms(100);
	
}
void uart_transmit (unsigned char data)
{
	while (!( UCSRA & (1<<UDRE)));
	UDR = data;
}
